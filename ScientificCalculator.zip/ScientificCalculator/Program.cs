﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Services;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace ScientificCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ArithmeticOperations.Arithmetic calculate = new ArithmeticOperations.Arithmetic();
            PowerOperations.Power  calculation = new PowerOperations.Power ();

            //Enter expression (e.g., num1 + num2 )
            //enter operation(+,-, *, /, %, x² , x³ , 3√ , √, xⁿ or x^(1 / y)))
            // xⁿ : alt + 252 , x³ : alt + 0179  , √:alt + 252 , x²: alt + 0178

            string input = Console.ReadLine();
            
            string[] parts = input.Split(' ');
            
            double num1 = double.Parse(parts[0]); 
            string operation = parts[1];
            double num2;
          
            switch (operation)
            {
                case "+":
                    num2 = double.Parse(parts[2]);
                    Console.WriteLine(calculate.Addition(num1, num2));
                    break;
                case "-":
                    num2 = double.Parse(parts[2]);
                    Console.WriteLine(calculate.Subtraction(num1, num2));
                    break;
                case "*":
                    num2 = double.Parse(parts[2]);
                    Console.WriteLine(calculate.Multiplication(num1, num2));
                    break;
                case "/":
                    num2 = double.Parse(parts[2]);
                    if (num2 == 0)
                    {
                        Console.WriteLine("Cannot divide by zero");                 
                    }
                    else
                    {
                        Console.WriteLine(calculate.Division(num1, num2));
                    }
                    break;
                case "%":
                    num2 = double.Parse(parts[2]);
                    if (num2 == 0)
                    {
                        Console.WriteLine("error :a mod 0 is undefined");
                    }
                    else
                    {
                        Console.WriteLine(calculate.Modulo(num1, num2));
                    }
                    break;
                case "x²":
                    Console.WriteLine(calculation.Square(num1));
                    break;
                case "x3":
                    Console.WriteLine(calculation.Cube(num1));
                    break;
                case "3√":
                    if (num1 < 0)
                    {
                        Console.WriteLine("Cube root is not defined for negative numbers.");
                    }
                    else
                    {
                        Console.WriteLine(calculation.CubeRoot(num1));
                    }
                    break;
                case "√":
                    if (num1 < 0)
                    {
                        Console.WriteLine("Square root is not defined for negative numbers.");
                    }
                    else
                    {
                        Console.WriteLine(calculation.SquareRoot(num1));
                    }
                    break;
                case "xⁿ":
                    num2 = double.Parse(parts[2]);
                    Console.WriteLine(calculation.Exponent(num1 , num2));
                    break;
                case "x^(1/y)":
                    double exponentValue = double.Parse(parts[2]);
                    if (exponentValue == 0)
                    {
                        Console.WriteLine("Cannot divide be zero");
                    }
                    else if(num1 < 0 && exponentValue % 2 == 0)
                    {
                        Console.WriteLine("Cannot calculate even - root of a negative number");
                    }
                    else
                    {
                        Console.WriteLine(calculation.FractionalExponent(num1, exponentValue));
                    }
                    break;
                default:
                    Console.WriteLine("Enter a valid operation");
                    break;
            }
        }
    }
}
