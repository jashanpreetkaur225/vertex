﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PowerOperations
{
    public class Power
    {
        public double Square(double number)
        {
            return number * number;
        }
        public double Cube(double number)
        {
            return number*number*number;
        }
        public double Exponent(double baseNumber, double exponentValue)
        {
            if (exponentValue == 0)
                return 1;

            double result = 1;

            // Handle negative exponents
            if (exponentValue < 0)
            {
                baseNumber = 1 / baseNumber;
                exponentValue = -exponentValue;
            }
            for (int i = 0; i < exponentValue; i++)
            {
                result *= baseNumber;
            }
            return result;
        }
        public double FractionalExponent(double baseNumber, double exponentValue)
        {
            double smallPositiveValue = 0.00001;
            double guess = baseNumber / 2.0;
            double previousGuess;
            do
            {
                previousGuess = guess;
                guess = ((exponentValue - 1.0) * previousGuess + (baseNumber / Math.Pow(previousGuess, exponentValue - 1))) / exponentValue;
            } while (Math.Abs(guess - previousGuess) >= smallPositiveValue);

            return guess;

        }
        public double SquareRoot(double number)
        {
            if (number < 2)
                return number;

            double y = number;
            double z = (y + (number / y)) / 2;

            while (Math.Abs(y - z) >= 0.00001)
            {
                y = z;
                z = (y + (number / y)) / 2;
            }
            return z;
        }
        public double CubeRoot(double number)
        {
            double guess = number / 3.0;
            double prevGuess = 0.0;
            double smallPositiveValue = 0.0000001;

            while (Math.Abs(guess - prevGuess) > smallPositiveValue)
            {
                prevGuess = guess;
                guess = (2.0 * guess + number / (guess * guess)) / 3.0;
            }

            return guess;
        } 
    }
}
